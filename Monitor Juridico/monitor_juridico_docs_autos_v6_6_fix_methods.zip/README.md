v6: baseada na versão que funcionava. Não mexe em Capa/Partes/Movs. Adiciona mini form em /ui/docs-v2/<CNJ> e endpoints v2:
- GET /processos/<CNJ>/documentos-publicos
- GET /processos/<CNJ>/autos
- POST /processos/<CNJ>/solicitar-atualizacao
- GET /processos/<CNJ>/solicitar-status
- GET /processos/<CNJ>/documentos/<key> (download)
Cria tabelas docs_v2_cache e updates_v2.
